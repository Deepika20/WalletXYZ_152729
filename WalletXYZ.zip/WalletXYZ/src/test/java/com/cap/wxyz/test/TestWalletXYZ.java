package com.cap.wxyz.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.cap.wxyz.bean.AccountHolder;
import com.cap.wxyz.exception.WalletXYZException;
import com.cap.wxyz.service.AccountHolderService;

public class TestWalletXYZ {

	AccountHolder ah = new AccountHolder();
	AccountHolderService ahs = new AccountHolderService();



@Test
public void testPassCreateAccount() throws WalletXYZException{
	String name = "Deepika";
	int age = 20;
	String PhoneNumber = "1234567890";
	String Gender = "f";
	String Password = "DEEPika@123";
	String ConfirmPassword = "DEEPika@123";
	String AccountNumber = "6789054321";
	boolean tocheck = ahs.createAccount(name, age,  Password, PhoneNumber, Gender, ConfirmPassword, AccountNumber );
	assertEquals(true, tocheck);
	
}
@Test
public void testPassPhoneNumber(){
	 
	 boolean testvar = ahs.validatePhoneNumber("1234567890");
	 assertEquals(true, testvar);
}
@Test
public void testPassGender(){
	 boolean testvar = ahs.validateGender("f");
	 assertEquals(true, testvar);
}
@Test
public void testPassName(){
	
	 boolean testvar = ahs.validateName("Deepika");
	 assertEquals(true, testvar);

}
@Test
public void testPassAge(){
	
	 boolean testvar = ahs.validateAge(23);
	 assertEquals(true, testvar);

}
@Test
public void testPassAccountNumber(){
	
	 boolean testvar = ahs.validateAccountNumber("1234567890");
	 assertEquals(true, testvar);

}

@Test
public void testPassMoneyDeposit(){
 	
boolean testvar = ahs.validateMoneyDeposit(1000);
 assertEquals(true, testvar);
}
public void testPassMoneyWithDraw(){
boolean testvar = ahs.validateMoneyWithdraw(ah, 1000);
 assertEquals(true, testvar);
}
@Test
public void testFailCreateAccount() throws WalletXYZException{
	String name = "deepika";
	int age = 2;
	String PhoneNumber = "123456789";
	String Gender = "p";
	String Password = "ika@123";
	String ConfirmPassword = "ika@123";
	String AccountNumber = "4567890";
	boolean tocheck = ahs.createAccount(name, age,  Password, PhoneNumber, Gender,ConfirmPassword, AccountNumber);
	assertEquals(false, tocheck);

}
@Test
public void testFailPhoneNumber(){
	
	 boolean testvar = ahs.validatePhoneNumber("123456789");
	 assertEquals(false, testvar);
}
@Test
public void testFailGender(){
	 boolean testvar = ahs.validateGender("p");
	 assertEquals(false, testvar);
}
@Test
public void testFailName(){
	
	 boolean testvar = ahs.validateName("d12pika");
	 assertEquals(false, testvar);

}
@Test
public void testFailAge(){
	
	 boolean testvar = ahs.validateAge(0);
	 assertEquals(false, testvar);

}
@Test
public void testFailMoneyDeposit(){
	 	
	boolean testvar = ahs.validateMoneyDeposit(0);
	 assertEquals(false, testvar);
}
@Test
public void testFailMoneyWithDraw(){
	boolean testvar = ahs.validateMoneyWithdraw(ah, 10);
	 assertEquals(false, testvar);
}
@Test
public void testFailAccountNumber(){
	
	 boolean testvar = ahs.validateAccountNumber("123456789");
	 assertEquals(true, testvar);

}





}



