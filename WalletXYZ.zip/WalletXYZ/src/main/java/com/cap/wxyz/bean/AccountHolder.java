package com.cap.wxyz.bean;
import java.util.ArrayList;

public class AccountHolder {
	private String name;
	private int age;
	private String phonenumber;
	private String gender;
	private ArrayList  apt = new ArrayList();
	//private static long number = 100;
	private String password;
	private String AccountNumber;
	private float balance = 0;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		//apt.add(balance);
		this.balance = balance;
	}
	public String getAccountNumber() {
		return AccountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		AccountNumber = accountNumber;
	}
	public ArrayList getApt() {
		return apt;
	}
	public void setApt(String string) {
		this.apt.add(string);
	}
	
	
	
	

}
