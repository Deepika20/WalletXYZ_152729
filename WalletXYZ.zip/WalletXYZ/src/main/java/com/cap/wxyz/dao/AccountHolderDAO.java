package com.cap.wxyz.dao;

import java.util.ArrayList;
import java.util.HashMap;

import com.cap.wxyz.bean.AccountHolder;
import com.cap.wxyz.exception.WalletXYZException;

public class AccountHolderDAO implements IAccountHolderDAO {
	HashMap<String, AccountHolder> hm = new HashMap<String, AccountHolder>();
	
	ArrayList al = new ArrayList();
	AccountHolderDAO ahdao;// = new AccountHolderDAO();
	public String createAccount(String name, int age, String Password, String PhoneNumber, String Gender, String AccountNumber) throws WalletXYZException{
		AccountHolder ah = new AccountHolder();
		ah.setAge(age);
		ah.setGender(Gender);
		ah.setName(name);
		ah.setPassword(Password);
		ah.setPhonenumber(PhoneNumber);	
		ah.setAccountNumber(AccountNumber);
		hm.put(ah.getPhonenumber(),ah);
		al.add(ah.getPhonenumber());
		return ah.getPhonenumber();
		
	}
	
	public boolean isLogin(String userId) throws WalletXYZException {
		// TODO Auto-generated method stub
		if(al.contains(userId)){
			
			return true;
		}
		System.out.println(" User Id"+ userId+"is invalid");
		return false;
	}
	public AccountHolder getAccountHolderObject(String userId) {
		// TODO Auto-generated method stub
		AccountHolder ah = hm.get(userId);
		return ah;
	}
	
	
	//}
	
	 



}
