package com.cap.wxyz.service;

import com.cap.wxyz.bean.AccountHolder;
import com.cap.wxyz.exception.WalletXYZException;

public interface IAccountHolderService {
	public boolean createAccount(String name, int age, String Password, String PhoneNumber, String Gender, String confirmPassword, String accountnumber) throws WalletXYZException;
	public Object getAccountHolderObject(String UserId);
	public float depositAmount(AccountHolder ah, float money);
	public float withdrawAmount(AccountHolder ah, float money);
	public float showBalance(AccountHolder ah);
	public float fundTranfer(AccountHolder ah, AccountHolder ah1, float money);

}
