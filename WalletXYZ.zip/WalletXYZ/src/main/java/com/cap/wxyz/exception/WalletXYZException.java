package com.cap.wxyz.exception;

public class WalletXYZException extends Exception {
	
	String message;
	
	public WalletXYZException(String msg)
	{
		message=msg;
	}
	
	@Override
	public String getMessage()
	{
		return message;
	}
}
