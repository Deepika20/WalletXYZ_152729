package com.cap.wxyz.service;

import com.cap.wxyz.bean.AccountHolder;
import com.cap.wxyz.dao.AccountHolderDAO;
import com.cap.wxyz.exception.WalletXYZException;

public class AccountHolderService implements IAccountHolderService {
	
	static String namePattern = "[A-Z]{1}[a-z]{2,}";		
	static String phonenumberPattern = "[0-9]{10}";
	static String genderPattern = "[f,F,m,M]";
	static String accountNumberPattern = "[0-9]{10}";
	AccountHolderDAO ahdao = new AccountHolderDAO();
	
	

	public  boolean createAccount(String name, int age, String Password, String PhoneNumber, String Gender, String confirmPassword, String AccountNumber) throws WalletXYZException{
		
		 if(validateAge(age) && validatePassword(Password, confirmPassword) && validateAccountNumber(AccountNumber))
			if(validateName(name) && validatePhoneNumber(PhoneNumber) && validateGender(Gender)){
				//AccountHolderDAO ahdao = new AccountHolderDAO();
				ahdao.createAccount(name,  age,Password,PhoneNumber,Gender, AccountNumber);	
				return true;
			}
		return false;
		
	}
	
	public boolean validateAccountNumber(String accountNumber) {
		// TODO Auto-generated method stub
		if(accountNumber.matches(accountNumberPattern))
			return true;
		System.out.println("Your AccountNumber should contain 10 digits");
		return false;
	}

	public float depositAmount(AccountHolder ah, float money){
		float total =ah.getBalance() + money;
		ah.setBalance(total);
		//ah.apt.add(money);
		ah.setApt("Deposited "+money);
		return money;
	}
	
	public AccountHolder getAccountHolderObject(String UserId){
		//AccountHolderDAO ahdao = new AccountHolderDAO();
		return ahdao.getAccountHolderObject(UserId);
	}
	
	public boolean validateLogin(String UserId) throws WalletXYZException{
		return ahdao.isLogin(UserId);
	}
	
	public static boolean validatePassword(String password, String confirmpassword) {
		if(password.matches("(.*[A-Z].*)") && password.matches("(.*[a-z].*)") && password.matches("(.*[0-9].*)") && password.matches("(.*[@#$%].*)") )
				if(password.matches(confirmpassword))
					return true;
				else{
					System.out.println("password and confirm password are not same");
					return false;
				}
		System.out.println("Password must consists atleast a capital letter, a small letter, a special character, a number ");
		System.out.println("For Example : Deepika@123");
		return false;
	}

	public static boolean validateAge(int age) {
		if(age > 5 && age < 150)
			return true;
		
		// TODO Auto-generated method stub
		System.out.println("Age must be greater than 5 ");
		return false;
	}


	public static boolean validatePhoneNumber(String phonenumber) {
		if(phonenumber.matches(phonenumberPattern))
			return true;
		else{
			System.out.println("Inavlid type for phonenumber \n Phone number consists 10 numbers");
			return false;
		}
	}

	public static boolean validateGender(String gender) {
		// TODO Auto-generated method stub
		if(gender.matches(genderPattern))			
			return true;
		else{
			System.out.println("Inavlid type for gender \n Enter f,F or m,M");
			return false;
		}
	}

	public static boolean validateName(String name) {
		if(name.matches(namePattern))
			return true;
		else{
			System.out.println("Inavlid type for name \nHave first letter as Capital and other are small letters");
			return false;
		}
	}
	
	public boolean validateMoneyDeposit(float money){
		if(money > 0)
			return true;
		return false;
	}
	public boolean validateMoneyWithdraw(AccountHolder ah, float money){
		if(money > 0 && money <= ah.getBalance()  )
			return true;
		return false;
	}
	

	public float withdrawAmount(AccountHolder ah, float money) {
		float total = ah.getBalance()-money;
		ah.setBalance(total);
		ah.setApt("Withdrawn "+money);
		return money;
		
	}

	public float fundTranfer(AccountHolder ahwithdraw, AccountHolder ahdeposit, float money) {
		// TODO Auto-generated method stub
				
		ahwithdraw.setBalance(ahwithdraw.getBalance() - money);
		ahdeposit.setBalance(ahdeposit.getBalance()+money);
		ahdeposit.setApt("Deposited "+money);
		ahwithdraw.setApt("Withdrawn "+money);
		return money;	
	}

	public float showBalance(AccountHolder ah) {
		// TODO Auto-generated method stub
		
		return (ah.getBalance());
		
	}
	public void printTransaction(AccountHolder ah){
		System.out.println("Your Tranactions are followed");
		System.out.println(ah.getApt());
		
	}
	

	
}
