package com.cap.wxyz.dao;

import com.cap.wxyz.bean.AccountHolder;
import com.cap.wxyz.exception.WalletXYZException;

public interface IAccountHolderDAO {
	public String createAccount(String name, int age, String Password, String PhoneNumber, String Gender, String AccountNumber)throws WalletXYZException;
	public AccountHolder getAccountHolderObject(String userId);

}
